import { TaskController } from "./modules/tasks/task.controller";

const controller = new TaskController();
controller.createDemoTasks();
