const TaskDetails= () => {
    return <div>Task</div>
}

export default TaskDetails